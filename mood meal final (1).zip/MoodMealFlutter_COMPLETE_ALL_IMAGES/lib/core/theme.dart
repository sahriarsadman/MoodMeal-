import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF4CAF50); // Green (#4CAF50)
  static const surface = Color(0xFFF7FAF7);
  static const text = Color(0xFF102015);

  // Mood colours (Design System)
  static const stressed = Color(0xFFE53935); // Red
  static const tired = Color(0xFF8E24AA); // Purple
  static const anxious = Color(0xFFFB8C00); // Orange
  static const happy = Color(0xFFFDD835); // Yellow
  static const focused = Color(0xFF1E88E5); // Blue
  static const calm = Color(0xFF5CC9A7); // Mint

  static const cardBorder = Color(0xFFE4EAE4);
}

ThemeData buildAppTheme() {
  final colorScheme = ColorScheme.fromSeed(
    seedColor: AppColors.primary,
    brightness: Brightness.light,
    surface: AppColors.surface,
  );

  return ThemeData(
    useMaterial3: true,
    colorScheme: colorScheme,
    scaffoldBackgroundColor: AppColors.surface,
    textTheme: const TextTheme(
      headlineSmall: TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.w700,
        color: AppColors.text,
      ),
      titleMedium: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w600,
        color: AppColors.text,
      ),
      bodyMedium: TextStyle(
        fontSize: 14,
        height: 1.4,
        color: AppColors.text,
      ),
    ),
    appBarTheme: const AppBarTheme(
      centerTitle: false,
      backgroundColor: Colors.transparent,
      elevation: 0,
    ),
   cardTheme: const CardThemeData(
  surfaceTintColor: Colors.transparent,
  color: Colors.white,
  elevation: 0,
  shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.all(Radius.circular(20)),
    side: BorderSide(color: AppColors.cardBorder),
  ),
),


    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.cardBorder),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.cardBorder),
      ),
    ),
    chipTheme: ChipThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
      side: const BorderSide(color: AppColors.cardBorder),
      labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
    ),
  );
}
