import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/theme.dart';
import 'screens/onboarding_screen.dart';
import 'screens/recommendations_screen.dart';
import 'screens/recipe_detail_screen.dart';
import 'screens/root_screen.dart';
import 'screens/search_screen.dart';
import 'state/app_state.dart';

void main() {
  runApp(const MoodMealApp());
}

class MoodMealApp extends StatelessWidget {
  const MoodMealApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'MoodMeal',
        theme: buildAppTheme(),
        initialRoute: '/',
        onGenerateRoute: (settings) {
          switch (settings.name) {
            case '/':
              return MaterialPageRoute(builder: (_) => const OnboardingScreen());
            case '/root':
              return MaterialPageRoute(builder: (_) => const RootScreen());
            case '/recommendations':
              return MaterialPageRoute(builder: (_) => const RecommendationsScreen());
            case '/recipe':
              final recipeId = settings.arguments as String;
              return MaterialPageRoute(builder: (_) => RecipeDetailScreen(recipeId: recipeId));
            case '/search':
              final q = settings.arguments as String;
              return MaterialPageRoute(builder: (_) => SearchScreen(initialQuery: q));
          }
          return MaterialPageRoute(
            builder: (_) => Scaffold(
              appBar: AppBar(title: const Text('Not found')),
              body: Center(child: Text('Route not found: ${settings.name}')),
            ),
          );
        },
      ),
    );
  }
}
