import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../models/mood.dart';

class MoodWheel extends StatelessWidget {
  final MoodKey? selected;
  final ValueChanged<MoodKey> onSelected;

  const MoodWheel({super.key, required this.selected, required this.onSelected});

  @override
  Widget build(BuildContext context) {
    final radius = 120.0;
    final centerSize = 98.0;
    return SizedBox(
      height: 320,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Center label
          Container(
            width: centerSize,
            height: centerSize,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: const Color(0xFFE4EAE4)),
              boxShadow: const [BoxShadow(blurRadius: 20, offset: Offset(0, 10), color: Color(0x14000000))],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.sentiment_satisfied_alt_rounded, size: 28, color: Theme.of(context).colorScheme.primary),
                const SizedBox(height: 6),
                Text(
                  selected == null ? 'How do you\nfeel?' : moodByKey(selected!).label,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ],
            ),
          ).animate().fadeIn(duration: 300.ms).scale(begin: const Offset(0.95, 0.95), end: const Offset(1, 1)),

          // Mood buttons in a circle
          for (int i = 0; i < moods.length; i++)
            _MoodDot(
              mood: moods[i],
              selected: selected == moods[i].key,
              onTap: () => onSelected(moods[i].key),
              offset: Offset(
                radius * math.cos((i / moods.length) * 2 * math.pi - math.pi / 2),
                radius * math.sin((i / moods.length) * 2 * math.pi - math.pi / 2),
              ),
            ),
        ],
      ),
    );
  }
}

class _MoodDot extends StatelessWidget {
  final Mood mood;
  final bool selected;
  final VoidCallback onTap;
  final Offset offset;

  const _MoodDot({required this.mood, required this.selected, required this.onTap, required this.offset});

  @override
  Widget build(BuildContext context) {
    final size = selected ? 66.0 : 60.0;
    return Transform.translate(
      offset: offset,
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: 200.ms,
          curve: Curves.easeOut,
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: mood.color,
            borderRadius: BorderRadius.circular(999),
            boxShadow: [
              BoxShadow(
                blurRadius: selected ? 18 : 10,
                offset: const Offset(0, 8),
                color: mood.color.withOpacity(0.25),
              ),
            ],
            border: Border.all(color: Colors.white, width: 3),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(mood.icon, color: Colors.white, size: 22),
              const SizedBox(height: 2),
              Text(
                mood.label,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 10.5,
                  height: 1.05,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ).animate(target: selected ? 1 : 0).shake(duration: 350.ms, hz: 3, offset: const Offset(2, 0)),
      ),
    );
  }
}
