import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../models/recipe.dart';

class RecipeCard extends StatelessWidget {
  final Recipe recipe;
  final bool isFavourite;
  final VoidCallback onTap;
  final VoidCallback onFavourite;

  const RecipeCard({
    super.key,
    required this.recipe,
    required this.isFavourite,
    required this.onTap,
    required this.onFavourite,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
                            ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: Image.asset(
                  recipe.imageAsset,
                  width: 74,
                  height: 74,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    width: 74,
                    height: 74,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Theme.of(context).colorScheme.primary.withOpacity(0.25),
                          Theme.of(context).colorScheme.primary.withOpacity(0.05),
                        ],
                      ),
                    ),
                    child: Icon(Icons.restaurant_rounded, size: 34, color: Theme.of(context).colorScheme.primary),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            recipe.title,
                            style: Theme.of(context).textTheme.titleMedium,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        IconButton(
                          onPressed: onFavourite,
                          icon: Icon(isFavourite ? Icons.favorite_rounded : Icons.favorite_border_rounded),
                          color: isFavourite ? Colors.redAccent : Colors.black54,
                          tooltip: isFavourite ? 'Remove from favourites' : 'Save to favourites',
                        ).animate(target: isFavourite ? 1 : 0).scale(end: const Offset(1.12, 1.12), duration: 180.ms),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      recipe.subtitle,
                      style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 6,
                      children: [
                        _InfoBadge(icon: Icons.timer_rounded, label: '${recipe.minutes} min'),
                        _InfoBadge(icon: Icons.local_fire_department_rounded, label: '${recipe.calories} cal'),
                        _InfoBadge(icon: Icons.people_alt_rounded, label: '${recipe.servings} serve'),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ).animate().fadeIn(duration: 250.ms).slideY(begin: 0.05, end: 0);
  }
}

class _InfoBadge extends StatelessWidget {
  final IconData icon;
  final String label;

  const _InfoBadge({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFF2F6F2),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFFE4EAE4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: Theme.of(context).colorScheme.primary),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600), // improved readability
          ),
        ],
      ),
    );
  }
}
