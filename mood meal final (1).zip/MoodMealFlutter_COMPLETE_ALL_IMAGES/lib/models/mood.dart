import 'package:flutter/material.dart';
import '../core/theme.dart';

enum MoodKey { stressed, tired, anxious, happy, focused, calm }

class Mood {
  final MoodKey key;
  final String label;
  final Color color;
  final IconData icon;

  const Mood({required this.key, required this.label, required this.color, required this.icon});
}

const moods = <Mood>[
  Mood(key: MoodKey.stressed, label: 'Stressed', color: AppColors.stressed, icon: Icons.bolt_rounded),
  Mood(key: MoodKey.tired, label: 'Tired', color: AppColors.tired, icon: Icons.nightlight_round),
  Mood(key: MoodKey.anxious, label: 'Anxious', color: AppColors.anxious, icon: Icons.psychology_alt_rounded),
  Mood(key: MoodKey.happy, label: 'Happy', color: AppColors.happy, icon: Icons.emoji_emotions_rounded),
  Mood(key: MoodKey.focused, label: 'Focused', color: AppColors.focused, icon: Icons.center_focus_strong_rounded),
  Mood(key: MoodKey.calm, label: 'Calm', color: AppColors.calm, icon: Icons.spa_rounded),
];

Mood moodByKey(MoodKey key) => moods.firstWhere((m) => m.key == key);
