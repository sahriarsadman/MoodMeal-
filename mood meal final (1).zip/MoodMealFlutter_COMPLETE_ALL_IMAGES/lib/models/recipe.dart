import '../models/mood.dart';

class Recipe {
  final String id;
  final String title;
  final String subtitle;

  final String imageAsset;

  final int minutes;
  final int calories;     // ✅ ADDED
  final int servings;

  final List<MoodKey> moods;

  final List<String> ingredients;
  final List<String> instructions;

  final String moodBenefits; // ✅ MUST be String (UI expects String)

  const Recipe({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.imageAsset,
    required this.minutes,
    required this.calories,   // ✅ ADDED
    required this.servings,
    required this.moods,
    required this.ingredients,
    required this.instructions,
    required this.moodBenefits, // ✅ String
  });
}
