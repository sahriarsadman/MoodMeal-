import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../widgets/recipe_card.dart';

class SearchScreen extends StatelessWidget {
  final String initialQuery;

  const SearchScreen({super.key, required this.initialQuery});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final results = state.searchRecipes(initialQuery);

    return Scaffold(
      appBar: AppBar(title: Text('Search: "$initialQuery"')),
      body: SafeArea(
        child: results.isEmpty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.search_off_rounded,
                          size: 54, color: Theme.of(context).colorScheme.primary),
                      const SizedBox(height: 12),
                      const Text('No results', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 6),
                      Text(
                        'Try searching a different recipe name or keyword.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                      ),
                    ],
                  ),
                ),
              )
            : ListView.separated(
                padding: const EdgeInsets.all(20),
                itemCount: results.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, index) {
                  final r = results[index];
                  return RecipeCard(
                    recipe: r,
                    isFavourite: state.isFavourite(r.id),
                    onFavourite: () => context.read<AppState>().toggleFavourite(r.id),
                    onTap: () => Navigator.of(context).pushNamed('/recipe', arguments: r.id),
                  );
                },
              ),
      ),
    );
  }
}
