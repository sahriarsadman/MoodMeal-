import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/mood.dart';
import '../state/app_state.dart';
import '../widgets/recipe_card.dart';

class RecommendationsScreen extends StatelessWidget {
  const RecommendationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final selectedMood = state.selectedMood;
    final items = state.recommendations;

    return Scaffold(
      appBar: AppBar(
        title: Text(selectedMood == null ? 'Recommendations' : '${moodByKey(selectedMood).label} meals'),
      ),
      body: SafeArea(
        child: ListView.separated(
          padding: const EdgeInsets.all(20),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final r = items[index];
            return RecipeCard(
              recipe: r,
              isFavourite: state.isFavourite(r.id),
              onFavourite: () => context.read<AppState>().toggleFavourite(r.id),
              onTap: () => Navigator.of(context).pushNamed('/recipe', arguments: r.id),
            );
          },
        ),
      ),
    );
  }
}
