import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/recipes.dart';
import '../state/app_state.dart';

class RecipeDetailScreen extends StatelessWidget {
  final String recipeId;

  const RecipeDetailScreen({super.key, required this.recipeId});

  @override
  Widget build(BuildContext context) {
    final recipe = recipes.firstWhere((r) => r.id == recipeId);
    final state = context.watch<AppState>();
    final isFav = state.isFavourite(recipe.id);

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(recipe.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          actions: [
            IconButton(
              onPressed: () => context.read<AppState>().toggleFavourite(recipe.id),
              icon: Icon(isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded),
              color: isFav ? Colors.redAccent : null,
              tooltip: isFav ? 'Remove from favourites' : 'Save to favourites',
            ),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 6, 20, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Hero image
                    ClipRRect(
                      borderRadius: BorderRadius.circular(24),
                      child: Image.asset(
                        recipe.imageAsset,
                        height: 190,
                        width: double.infinity,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          height: 190,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(24),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Theme.of(context).colorScheme.primary.withOpacity(0.22),
                                Theme.of(context).colorScheme.primary.withOpacity(0.06),
                              ],
                            ),
                          ),
                          child: Icon(Icons.restaurant_rounded, size: 52, color: Theme.of(context).colorScheme.primary),
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text(recipe.subtitle,
                        style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _badge(context, Icons.timer_rounded, '${recipe.minutes} min'),
                        _badge(context, Icons.local_fire_department_rounded, '${recipe.calories} cal'),
                        _badge(context, Icons.people_alt_rounded, '${recipe.servings} serve'),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              const TabBar(
                tabs: [
                  Tab(text: 'Ingredients'),
                  Tab(text: 'Instructions'),
                ],
              ),

              // Improvement 1: Mood Benefits section placed directly under tabs (high visibility)
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary.withOpacity(0.10),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Theme.of(context).colorScheme.primary.withOpacity(0.18)),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.primary,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.spa_rounded, color: Colors.white),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Mood Benefits', style: TextStyle(fontWeight: FontWeight.w800)),
                            const SizedBox(height: 6),
                            Text(
                              recipe.moodBenefits,
                              style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: TabBarView(
                  children: [
                    _ListPanel(items: recipe.ingredients, bullet: true),
                    _ListPanel(items: recipe.instructions, bullet: false),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _badge(BuildContext context, IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFF2F6F2),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFFE4EAE4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: Theme.of(context).colorScheme.primary),
          const SizedBox(width: 6),
          Text(text, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _ListPanel extends StatelessWidget {
  final List<String> items;
  final bool bullet;

  const _ListPanel({required this.items, required this.bullet});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 20),
      itemCount: items.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, i) {
        final text = items[i];
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (bullet)
              Padding(
                padding: const EdgeInsets.only(top: 3),
                child: Container(
                  width: 7,
                  height: 7,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary,
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              )
            else
              Text('${i + 1}. ', style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(width: 10),
            Expanded(child: Text(text)),
          ],
        );
      },
    );
  }
}
