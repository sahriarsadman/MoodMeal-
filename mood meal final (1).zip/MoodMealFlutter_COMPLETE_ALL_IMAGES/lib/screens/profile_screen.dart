import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  Future<void> _editField({
    required BuildContext context,
    required String title,
    required String initial,
    required ValueChanged<String> onSaved,
  }) async {
    final controller = TextEditingController(text: initial);
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: 'Enter value...'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.of(context).pop(controller.text), child: const Text('Save')),
        ],
      ),
    );
    if (result != null) {
      onSaved(result.trim().isEmpty ? initial : result.trim());
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final profile = state.profile;

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primary.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Icon(Icons.person_rounded, size: 30, color: Theme.of(context).colorScheme.primary),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Your Health Profile', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 4),
                          Text(
                            'Edit preferences to improve recommendations.',
                            style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),

            // Improvement 2: reorganised profile menu under a clear sub-header
            const Padding(
              padding: EdgeInsets.only(left: 4, bottom: 8),
              child: Text('Health Profile', style: TextStyle(fontWeight: FontWeight.w900)),
            ),
            Card(
              child: Column(
                children: [
                  _RowItem(
                    icon: Icons.restaurant_rounded,
                    title: 'Dietary preferences',
                    value: profile.dietaryPreference,
                    onTap: () => _editField(
                      context: context,
                      title: 'Dietary preferences',
                      initial: profile.dietaryPreference,
                      onSaved: (v) {
                        profile.dietaryPreference = v;
                        context.read<AppState>().notifyListeners();
                      },
                    ),
                  ),
                  const _Divider(),
                  _RowItem(
                    icon: Icons.warning_amber_rounded,
                    title: 'Allergies',
                    value: profile.allergies,
                    onTap: () => _editField(
                      context: context,
                      title: 'Allergies',
                      initial: profile.allergies,
                      onSaved: (v) {
                        profile.allergies = v;
                        context.read<AppState>().notifyListeners();
                      },
                    ),
                  ),
                  const _Divider(),
                  _RowItem(
                    icon: Icons.flag_rounded,
                    title: 'Health goals',
                    value: profile.healthGoal,
                    onTap: () => _editField(
                      context: context,
                      title: 'Health goals',
                      initial: profile.healthGoal,
                      onSaved: (v) {
                        profile.healthGoal = v;
                        context.read<AppState>().notifyListeners();
                      },
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            const Padding(
              padding: EdgeInsets.only(left: 4, bottom: 8),
              child: Text('Settings', style: TextStyle(fontWeight: FontWeight.w900)),
            ),
            Card(
              child: Column(
                children: const [
                  _RowItemStatic(icon: Icons.lock_rounded, title: 'Privacy', value: 'On-device only (prototype)'),
                  _Divider(),
                  _RowItemStatic(icon: Icons.accessibility_new_rounded, title: 'Accessibility', value: 'WCAG-friendly layout'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Divider extends StatelessWidget {
  const _Divider();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.only(left: 56),
      child: Divider(height: 1),
    );
  }
}

class _RowItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;
  final VoidCallback onTap;

  const _RowItem({required this.icon, required this.title, required this.value, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.12),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: Theme.of(context).colorScheme.primary),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(value, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                ],
              ),
            ),
            Icon(Icons.chevron_right_rounded, color: Theme.of(context).colorScheme.onSurfaceVariant),
          ],
        ),
      ),
    );
  }
}

class _RowItemStatic extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;

  const _RowItemStatic({required this.icon, required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary.withOpacity(0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: Theme.of(context).colorScheme.primary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(value, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
