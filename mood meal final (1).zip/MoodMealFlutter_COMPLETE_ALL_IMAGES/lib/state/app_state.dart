import 'package:flutter/foundation.dart';
import '../data/recipes.dart';
import '../models/mood.dart';
import '../models/recipe.dart';

class UserProfile {
  String dietaryPreference;
  String allergies;
  String healthGoal;

  UserProfile({
    this.dietaryPreference = 'None',
    this.allergies = 'None',
    this.healthGoal = 'General wellness',
  });
}

class AppState extends ChangeNotifier {
  MoodKey? _selectedMood;
  final Set<String> _favourites = <String>{};
  final UserProfile profile = UserProfile();

  MoodKey? get selectedMood => _selectedMood;
  Set<String> get favourites => _favourites;

  void selectMood(MoodKey mood) {
    _selectedMood = mood;
    notifyListeners();
  }

  void clearMood() {
    _selectedMood = null;
    notifyListeners();
  }

  bool isFavourite(String recipeId) => _favourites.contains(recipeId);

  void toggleFavourite(String recipeId) {
    if (_favourites.contains(recipeId)) {
      _favourites.remove(recipeId);
    } else {
      _favourites.add(recipeId);
    }
    notifyListeners();
  }

  List<Recipe> get recommendations {
    if (_selectedMood == null) return recipes;
    return recipes.where((r) => r.moods.contains(_selectedMood)).toList(growable: false);
  }

  List<Recipe> searchRecipes(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return recipes;
    return recipes
        .where((r) => r.title.toLowerCase().contains(q) || r.subtitle.toLowerCase().contains(q))
        .toList(growable: false);
  }

  List<Recipe> get favouriteRecipes =>
      recipes.where((r) => _favourites.contains(r.id)).toList(growable: false);
}
