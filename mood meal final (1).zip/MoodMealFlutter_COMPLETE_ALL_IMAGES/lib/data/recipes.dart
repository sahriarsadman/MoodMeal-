import '../models/mood.dart';
import '../models/recipe.dart';

// NOTE: This is a small offline dataset so the prototype works without any API.
// You can replace this with a real dataset / backend later.

const recipes = <Recipe>[
  Recipe(
    id: 'r1',
    title: 'Salmon & Avocado Bowl',
    subtitle: 'Omega-3 rich comfort bowl',
    imageAsset: 'assets/images/foods/salmon_avocado.jpg',
    minutes: 25,
    calories: 450,
    servings: 2,
    moods: [MoodKey.stressed, MoodKey.anxious, MoodKey.calm],
    ingredients: [
      '2 salmon fillets',
      '1 ripe avocado',
      '1 cup cooked brown rice',
      '1 cup baby spinach',
      '1 tbsp olive oil',
      '1 tbsp lemon juice',
      'Salt & pepper',
    ],
    instructions: [
      'Season salmon with salt and pepper.',
      'Pan-sear salmon 3–4 minutes per side.',
      'Assemble bowl with rice and spinach.',
      'Slice avocado and add on top.',
      'Drizzle olive oil and lemon juice. Serve warm.',
    ],
    moodBenefits:
        'Salmon provides omega-3 fatty acids which support brain health and may help regulate stress response. Avocado and spinach contribute magnesium and B vitamins, supporting calm focus.',
  ),

  Recipe(
    id: 'r2',
    title: 'Banana Oat Smoothie',
    subtitle: 'Quick energy + magnesium boost',
    imageAsset: 'assets/images/foods/banana_oatmeal.jpg',
    minutes: 7,
    calories: 320,
    servings: 1,
    moods: [MoodKey.tired, MoodKey.focused],
    ingredients: [
      '1 banana',
      '1/2 cup rolled oats',
      '1 cup milk (or oat milk)',
      '1 tbsp peanut butter',
      '1 tsp honey (optional)',
      'Pinch of cinnamon',
    ],
    instructions: [
      'Add all ingredients to a blender.',
      'Blend until smooth.',
      'Serve chilled. Add ice if preferred.',
    ],
    moodBenefits:
        'Complex carbs from oats provide steady energy for concentration, while banana and nut butter contribute B vitamins and magnesium to reduce fatigue.',
  ),

  Recipe(
    id: 'r3',
    title: 'Turmeric Lentil Soup',
    subtitle: 'Warming, anti-inflammatory comfort',
    imageAsset: 'assets/images/foods/lentil_soup.jpg',
    minutes: 30,
    calories: 410,
    servings: 3,
    moods: [MoodKey.stressed, MoodKey.calm],
    ingredients: [
      '1 cup red lentils',
      '1 onion (diced)',
      '2 garlic cloves (minced)',
      '1 tsp turmeric',
      '1 tsp cumin',
      '4 cups vegetable stock',
      'Salt & pepper',
      'Lemon wedge',
    ],
    instructions: [
      'Sauté onion and garlic until soft.',
      'Stir in turmeric and cumin for 30 seconds.',
      'Add lentils and stock; simmer 20 minutes.',
      'Season to taste. Finish with lemon.',
    ],
    moodBenefits:
        'Lentils provide folate and steady carbohydrates for balanced mood. Turmeric’s curcumin is linked to inflammation support, which can be associated with wellbeing.',
  ),

  Recipe(
    id: 'r4',
    title: 'Greek Yogurt Berry Parfait',
    subtitle: 'Bright, high-protein mood lift',
    imageAsset: 'assets/images/foods/berry_smoothie.jpg',
    minutes: 10,
    calories: 290,
    servings: 1,
    moods: [MoodKey.happy, MoodKey.focused],
    ingredients: [
      '1 cup Greek yogurt',
      '1/2 cup mixed berries',
      '2 tbsp granola',
      '1 tsp chia seeds',
    ],
    instructions: [
      'Layer yogurt, berries, and granola in a glass.',
      'Top with chia seeds. Enjoy immediately.',
    ],
    moodBenefits:
        'Protein supports stable blood sugar, while berries provide antioxidants. A stable energy curve can help improve motivation and focus.',
  ),

  Recipe(
    id: 'r5',
    title: 'Dark Chocolate Almond Bites',
    subtitle: 'Small treat for a gentle lift',
    imageAsset: 'assets/images/foods/mushroom_risotto.jpg',
    minutes: 15,
    calories: 180,
    servings: 2,
    moods: [MoodKey.happy, MoodKey.anxious],
    ingredients: [
      '60g dark chocolate (70%+)',
      '1/3 cup almonds',
      'Pinch of sea salt',
    ],
    instructions: [
      'Melt dark chocolate gently (microwave or bain-marie).',
      'Stir in almonds and a pinch of salt.',
      'Spoon onto baking paper and chill 10 minutes.',
    ],
    moodBenefits:
        'Dark chocolate can provide a small mood lift and magnesium; almonds add healthy fats that support steady energy.',
  ),
];

List<Recipe> filterRecipesByMood(MoodKey mood) =>
    recipes.where((r) => r.moods.contains(mood)).toList();

List<Recipe> searchRecipes(String query) {
  final q = query.trim().toLowerCase();
  if (q.isEmpty) return recipes;
  return recipes.where((r) {
    if (r.title.toLowerCase().contains(q)) return true;
    if (r.subtitle.toLowerCase().contains(q)) return true;
    return r.ingredients.any((i) => i.toLowerCase().contains(q));
  }).toList();
}
