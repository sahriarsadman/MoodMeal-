package com.example.moodmeal

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
